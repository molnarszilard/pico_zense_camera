# Library for PicoZense

Compiled files for other distributions can be found on https://www.picozense.com/en/sdk.html or https://github.com/PicoInteractive/ZenseSDK_Linux/tree/Ubuntu16.04.